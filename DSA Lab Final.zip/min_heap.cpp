#include <iostream>
using namespace std;

const int MAX_SIZE = 100;

class MinHeap {
    int heap[MAX_SIZE];
    int size;
    void heapifyUp(int idx) {
        while (idx > 0 && heap[(idx - 1) / 2] > heap[idx]) {
            swap(heap[idx], heap[(idx - 1) / 2]);
            idx = (idx - 1) / 2;
        }
    }
public:
    MinHeap() : size(0) {}
    void heapify(int idx) {
        int smallest = idx;
        int left = 2 * idx + 1;
        int right = 2 * idx + 2;
        if (left < size && heap[left] < heap[smallest])
            smallest = left;
        if (right < size && heap[right] < heap[smallest])
            smallest = right;
        if (smallest != idx) {
            swap(heap[idx], heap[smallest]);
            heapify(smallest);
        }
    }
    void insert(int val) {
        if (size == MAX_SIZE) {
            cout << "Heap overflow\n";
            return;
        }
        heap[size] = val;
        heapifyUp(size);
        size++;
    }
    int extractMin() {
        if (size == 0) throw runtime_error("Heap is empty");
        int minVal = heap[0];
        heap[0] = heap[size - 1];
        size--;
        heapify(0);
        return minVal;
    }
    int getMin() {
        if (size == 0) throw runtime_error("Heap is empty");
        return heap[0];
    }
    bool isEmpty() { return size == 0; }
    void printHeap() {
        for (int i = 0; i < size; ++i) cout << heap[i] << " ";
        cout << endl;
    }
};

int main() {
    MinHeap h;
    h.insert(10);
    h.insert(5);
    h.insert(3);
    h.insert(2);
    h.insert(8);

    cout << "Heap: ";
    h.printHeap();

    cout << "Min: " << h.getMin() << endl;
    cout << "Extracted Min: " << h.extractMin() << endl;
    cout << "Heap after extraction: ";
    h.printHeap();

    h.insert(1);
    h.insert(7);
    h.heapify(0); // manual heapify from root
    cout << "Heap after manual heapify: ";
    h.printHeap();

    return 0;
}