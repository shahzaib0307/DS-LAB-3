#include <iostream>
#include <cstring>
#include <cctype>
#include <cmath>
using namespace std;

const int MAX_SIZE = 100;

class CharStack {
    char arr[MAX_SIZE];
    int top;
public:
    CharStack() : top(-1) {}
    void push(char c) { if (top < MAX_SIZE - 1) arr[++top] = c; }
    char pop() { return (top >= 0) ? arr[top--] : '\0'; }
    char peek() { return (top >= 0) ? arr[top] : '\0'; }
    bool isEmpty() { return top == -1; }
    bool isFull() { return top == MAX_SIZE - 1; }
};

class IntStack {
    int arr[MAX_SIZE];
    int top;
public:
    IntStack() : top(-1) {}
    void push(int x) { if (top < MAX_SIZE - 1) arr[++top] = x; }
    int pop() { return (top >= 0) ? arr[top--] : 0; }
    int peek() { return (top >= 0) ? arr[top] : 0; }
    bool isEmpty() { return top == -1; }
    bool isFull() { return top == MAX_SIZE - 1; }
};

int precedence(char op) {
    if (op == '^') return 3;
    if (op == '*' || op == '/') return 2;
    if (op == '+' || op == '-') return 1;
    return 0;
}

bool isOperator(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
}

string infixToPostfix(const string& infix) {
    CharStack s;
    string postfix;
    for (size_t i = 0; i < infix.length(); ++i) {
        char c = infix[i];
        if (isspace(c)) continue;
        if (isalnum(c)) {
            postfix += c;
        } else if (c == '(') {
            s.push(c);
        } else if (c == ')') {
            while (!s.isEmpty() && s.peek() != '(')
                postfix += s.pop();
            if (!s.isEmpty()) s.pop();
        } else if (isOperator(c)) {
            while (!s.isEmpty() && precedence(s.peek()) >= precedence(c))
                postfix += s.pop();
            s.push(c);
        }
    }
    while (!s.isEmpty()) postfix += s.pop();
    return postfix;
}

string infixToPrefix(const string& infix) {
    string rev;
    for (int i = infix.length() - 1; i >= 0; --i) {
        char c = infix[i];
        if (c == '(') rev += ')';
        else if (c == ')') rev += '(';
        else rev += c;
    }
    string postfix = infixToPostfix(rev);
    string prefix(postfix.rbegin(), postfix.rend());
    return prefix;
}

int evalPostfix(const string& postfix) {
    IntStack s;
    for (size_t i = 0; i < postfix.length(); ++i) {
        char c = postfix[i];
        if (isspace(c)) continue;
        if (isdigit(c)) {
            s.push(c - '0');
        } else if (isOperator(c)) {
            int b = s.pop();
            int a = s.pop();
            switch (c) {
                case '+': s.push(a + b); break;
                case '-': s.push(a - b); break;
                case '*': s.push(a * b); break;
                case '/': s.push(a / b); break;
                case '^': s.push(pow(a, b)); break;
            }
        }
    }
    return s.pop();
}

int evalPrefix(const string& prefix) {
    IntStack s;
    for (int i = prefix.length() - 1; i >= 0; --i) {
        char c = prefix[i];
        if (isspace(c)) continue;
        if (isdigit(c)) {
            s.push(c - '0');
        } else if (isOperator(c)) {
            int a = s.pop();
            int b = s.pop();
            switch (c) {
                case '+': s.push(a + b); break;
                case '-': s.push(a - b); break;
                case '*': s.push(a * b); break;
                case '/': s.push(a / b); break;
                case '^': s.push(pow(a, b)); break;
            }
        }
    }
    return s.pop();
}

int main() {
    string infix = "((2+3)*4)-5";
    cout << infix << endl;
    string postfix = infixToPostfix(infix);
    cout << postfix << endl;
    cout << evalPostfix(postfix) << endl;
    string prefix = infixToPrefix(infix);
    cout << prefix << endl;
    cout << evalPrefix(prefix) << endl;
    return 0;
}