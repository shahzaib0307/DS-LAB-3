#include <iostream>
using namespace std;

const int MAX_SIZE = 100;

class Queue
{
    int arr[MAX_SIZE];
    int front, rear;

public:
    Queue() : front(0), rear(-1) {}
    bool isEmpty() { return front > rear; }
    bool isFull() { return rear == MAX_SIZE - 1; }
    void enqueue(int x)
    {
        if (!isFull())
            arr[++rear] = x;
    }
    int dequeue() { return (!isEmpty()) ? arr[front++] : -1; }
    int peek() { return (!isEmpty()) ? arr[front] : -1; }
};

class CircularQueue
{
    int arr[MAX_SIZE];
    int front, rear, count;

public:
    CircularQueue() : front(0), rear(0), count(0) {}
    bool isEmpty() { return count == 0; }
    bool isFull() { return count == MAX_SIZE; }
    void enqueue(int x)
    {
        if (!isFull())
        {
            arr[rear] = x;
            rear = (rear + 1) % MAX_SIZE;
            count++;
        }
    }
    int dequeue()
    {
        if (!isEmpty())
        {
            int val = arr[front];
            front = (front + 1) % MAX_SIZE;
            count--;
            return val;
        }
        return -1;
    }
    int peek() { return (!isEmpty()) ? arr[front] : -1; }
};

class Deque
{
    int arr[MAX_SIZE];
    int front, rear, count;

public:
    Deque() : front(0), rear(0), count(0) {}
    bool isEmpty() { return count == 0; }
    bool isFull() { return count == MAX_SIZE; }
    void enqueueFront(int x)
    {
        if (!isFull())
        {
            front = (front - 1 + MAX_SIZE) % MAX_SIZE;
            arr[front] = x;
            count++;
        }
    }
    void enqueueRear(int x)
    {
        if (!isFull())
        {
            arr[rear] = x;
            rear = (rear + 1) % MAX_SIZE;
            count++;
        }
    }
    int dequeueFront()
    {
        if (!isEmpty())
        {
            int val = arr[front];
            front = (front + 1) % MAX_SIZE;
            count--;
            return val;
        }
        return -1;
    }
    int dequeueRear()
    {
        if (!isEmpty())
        {
            rear = (rear - 1 + MAX_SIZE) % MAX_SIZE;
            int val = arr[rear];
            count--;
            return val;
        }
        return -1;
    }
    int peekFront() { return (!isEmpty()) ? arr[front] : -1; }
    int peekRear() { return (!isEmpty()) ? arr[(rear - 1 + MAX_SIZE) % MAX_SIZE] : -1; }
};

int main()
{
    Queue q;
    q.enqueue(1);
    q.enqueue(2);
    q.enqueue(3);
    cout << q.dequeue() << " " << q.peek() << endl;

    CircularQueue cq;
    cq.enqueue(10);
    cq.enqueue(20);
    cq.enqueue(30);
    cout << cq.dequeue() << " " << cq.peek() << endl;

    Deque d;
    d.enqueueRear(100);
    d.enqueueFront(200);
    d.enqueueRear(300);
    cout << d.dequeueFront() << " " << d.dequeueRear() << endl;

    return 0;
}