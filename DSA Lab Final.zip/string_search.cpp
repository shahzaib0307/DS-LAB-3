#include <iostream>
#include <cstring>
using namespace std;

// Brute Force Search
int bruteForce(const char* text, const char* pattern) {
    int n = strlen(text), m = strlen(pattern);
    for (int i = 0; i <= n - m; i++) {
        int j = 0;
        while (j < m && text[i + j] == pattern[j]) j++;
        if (j == m) return i;
    }
    return -1;
}

// Boyer-Moore (Bad Character Heuristic)
int boyerMoore(const char* text, const char* pattern) {
    int n = strlen(text), m = strlen(pattern);
    int badChar[256];
    for (int i = 0; i < 256; i++) badChar[i] = -1;
    for (int i = 0; i < m; i++) badChar[(unsigned char)pattern[i]] = i;
    int s = 0;
    while (s <= n - m) {
        int j = m - 1;
        while (j >= 0 && pattern[j] == text[s + j]) j--;
        if (j < 0) return s;
        else s += max(1, j - badChar[(unsigned char)text[s + j]]);
    }
    return -1;
}

// KMP Search
void computeLPS(const char* pattern, int* lps, int m) {
    int len = 0;
    lps[0] = 0;
    int i = 1;
    while (i < m) {
        if (pattern[i] == pattern[len]) {
            len++;
            lps[i] = len;
            i++;
        } else {
            if (len != 0) len = lps[len - 1];
            else { lps[i] = 0; i++; }
        }
    }
}

int kmpSearch(const char* text, const char* pattern) {
    int n = strlen(text), m = strlen(pattern);
    int lps[1000]; // assuming pattern length <= 1000
    computeLPS(pattern, lps, m);
    int i = 0, j = 0;
    while (i < n) {
        if (pattern[j] == text[i]) { i++; j++; }
        if (j == m) return i - j;
        else if (i < n && pattern[j] != text[i]) {
            if (j != 0) j = lps[j - 1];
            else i++;
        }
    }
    return -1;
}

// Rabin-Karp Search
int rabinKarp(const char* text, const char* pattern) {
    int n = strlen(text), m = strlen(pattern);
    const int d = 256, q = 101;
    int h = 1;
    for (int i = 0; i < m - 1; i++) h = (h * d) % q;
    int p = 0, t = 0;
    for (int i = 0; i < m; i++) {
        p = (d * p + pattern[i]) % q;
        t = (d * t + text[i]) % q;
    }
    for (int i = 0; i <= n - m; i++) {
        if (p == t) {
            int j = 0;
            while (j < m && text[i + j] == pattern[j]) j++;
            if (j == m) return i;
        }
        if (i < n - m) {
            t = (d * (t - text[i] * h) + text[i + m]) % q;
            if (t < 0) t += q;
        }
    }
    return -1;
}

int main() {
    const char text[] = "ABAAABCD";
    const char pattern[] = "ABC";
    cout << "BruteForce: " << bruteForce(text, pattern) << endl;
    cout << "BoyerMoore: " << boyerMoore(text, pattern) << endl;
    cout << "KMP: " << kmpSearch(text, pattern) << endl;
    cout << "RabinKarp: " << rabinKarp(text, pattern) << endl;
    return 0;
}