#include <iostream>
using namespace std;

void bubbleSort(int arr[], int n) {
    for (int i = 0; i < n-1; ++i) {
        for (int j = 0; j < n-i-1; ++j) {
            if (arr[j] > arr[j+1]) {
                int temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
}

void insertionSort(int arr[], int n) {
    for (int i = 1; i < n; ++i) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j+1] = arr[j];
            --j;
        }
        arr[j+1] = key;
    }
}

void selectionSort(int arr[], int n) {
    for (int i = 0; i < n-1; ++i) {
        int minIdx = i;
        for (int j = i+1; j < n; ++j) {
            if (arr[j] < arr[minIdx])
                minIdx = j;
        }
        int temp = arr[i];
        arr[i] = arr[minIdx];
        arr[minIdx] = temp;
    }
}

void printArray(int arr[], int n) {
    for (int i = 0; i < n; ++i)
        cout << arr[i] << " ";
    cout << endl;
}

int main() {
    int arr1[] = {5, 2, 9, 1, 5, 6};
    int arr2[] = {5, 2, 9, 1, 5, 6};
    int arr3[] = {5, 2, 9, 1, 5, 6};
    int n = 6;

    cout << "Original array: ";
    printArray(arr1, n);

    bubbleSort(arr1, n);
    cout << "Bubble sorted: ";
    printArray(arr1, n);

    insertionSort(arr2, n);
    cout << "Insertion sorted: ";
    printArray(arr2, n);

    selectionSort(arr3, n);
    cout << "Selection sorted: ";
    printArray(arr3, n);

    return 0;
}