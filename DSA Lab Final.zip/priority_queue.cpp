#include <iostream>
using namespace std;

const int MAX_SIZE = 100;

class PriorityQueue {
    int arr[MAX_SIZE];
    int size;
    void heapifyUp(int i) {
        while (i > 0 && arr[(i - 1) / 2] < arr[i]) {
            swap(arr[i], arr[(i - 1) / 2]);
            i = (i - 1) / 2;
        }
    }
    void heapifyDown(int i) {
        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        if (left < size && arr[left] > arr[largest]) largest = left;
        if (right < size && arr[right] > arr[largest]) largest = right;
        if (largest != i) {
            swap(arr[i], arr[largest]);
            heapifyDown(largest);
        }
    }
public:
    PriorityQueue() : size(0) {}
    void push(int x) {
        if (size < MAX_SIZE) {
            arr[size] = x;
            heapifyUp(size);
            size++;
        }
    }
    int pop() {
        if (size == 0) return -1;
        int maxVal = arr[0];
        arr[0] = arr[size - 1];
        size--;
        heapifyDown(0);
        return maxVal;
    }
    int top() {
        if (size == 0) return -1;
        return arr[0];
    }
    bool isEmpty() { return size == 0; }
};

int main() {
    PriorityQueue pq;
    pq.push(10);
    pq.push(30);
    pq.push(20);
    pq.push(40);
    cout << pq.top() << endl;
    cout << pq.pop() << endl;
    cout << pq.top() << endl;
    return 0;
}