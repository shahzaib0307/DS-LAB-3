#include <iostream>
using namespace std;

const int INIT_SIZE = 8;
const double LOAD_FACTOR = 0.7;

class HashTable {
    int* table;
    int capacity;
    int count;
    int EMPTY = -1;

    int hash(int key) { return key % capacity; }

    void rehash() {
        int old_capacity = capacity;
        int* old_table = table;

        capacity *= 2;
        table = new int[capacity];
        for (int i = 0; i < capacity; ++i) table[i] = EMPTY;
        count = 0;

        for (int i = 0; i < old_capacity; ++i) {
            if (old_table[i] != EMPTY) insert(old_table[i]);
        }
        delete[] old_table;
    }

public:
    HashTable() : capacity(INIT_SIZE), count(0) {
        table = new int[capacity];
        for (int i = 0; i < capacity; ++i) table[i] = EMPTY;
    }
    ~HashTable() { delete[] table; }

    void insert(int key) {
        if ((double)count / capacity > LOAD_FACTOR) rehash();
        int idx = hash(key);
        while (table[idx] != EMPTY) {
            if (table[idx] == key) return; // No duplicates
            idx = (idx + 1) % capacity;
        }
        table[idx] = key;
        count++;
    }

    bool search(int key) {
        int idx = hash(key);
        int start = idx;
        while (table[idx] != EMPTY) {
            if (table[idx] == key) return true;
            idx = (idx + 1) % capacity;
            if (idx == start) break;
        }
        return false;
    }

    void printTable() {
        for (int i = 0; i < capacity; ++i) {
            if (table[i] != EMPTY)
                cout << table[i] << " ";
            else
                cout << "_ ";
        }
        cout << endl;
    }
};

int main() {
    HashTable ht;
    for (int i = 1; i <= 10; ++i) {
        ht.insert(i * 3);
        ht.printTable();
    }
    cout << "Search 9: " << (ht.search(9) ? "Found" : "Not Found") << endl;
    cout << "Search 21: " << (ht.search(21) ? "Found" : "Not Found") << endl;
    return 0;
}