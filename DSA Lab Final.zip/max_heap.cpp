#include <iostream>
using namespace std;

const int MAX_SIZE = 100;

class MaxHeap {
    int heap[MAX_SIZE];
    int size;
    void heapifyUp(int idx) {
        while (idx > 0 && heap[(idx - 1) / 2] < heap[idx]) {
            swap(heap[idx], heap[(idx - 1) / 2]);
            idx = (idx - 1) / 2;
        }
    }
public:
    MaxHeap() : size(0) {}
    void heapify(int idx) {
        int largest = idx;
        int left = 2 * idx + 1;
        int right = 2 * idx + 2;
        if (left < size && heap[left] > heap[largest])
            largest = left;
        if (right < size && heap[right] > heap[largest])
            largest = right;
        if (largest != idx) {
            swap(heap[idx], heap[largest]);
            heapify(largest);
        }
    }
    void insert(int val) {
        if (size == MAX_SIZE) {
            cout << "Heap overflow\n";
            return;
        }
        heap[size] = val;
        heapifyUp(size);
        size++;
    }
    int extractMax() {
        if (size == 0) throw runtime_error("Heap is empty");
        int maxVal = heap[0];
        heap[0] = heap[size - 1];
        size--;
        heapify(0);
        return maxVal;
    }
    int getMax() {
        if (size == 0) throw runtime_error("Heap is empty");
        return heap[0];
    }
    bool isEmpty() { return size == 0; }
    void printHeap() {
        for (int i = 0; i < size; ++i) cout << heap[i] << " ";
        cout << endl;
    }
};

int main() {
    MaxHeap h;
    h.insert(10);
    h.insert(5);
    h.insert(3);
    h.insert(2);
    h.insert(8);

    cout << "Heap: ";
    h.printHeap();

    cout << "Max: " << h.getMax() << endl;
    cout << "Extracted Max: " << h.extractMax() << endl;
    cout << "Heap after extraction: ";
    h.printHeap();

    h.insert(15);
    h.insert(7);
    h.heapify(0); // manual heapify from root
    cout << "Heap after manual heapify: ";
    h.printHeap();

    return 0;
}